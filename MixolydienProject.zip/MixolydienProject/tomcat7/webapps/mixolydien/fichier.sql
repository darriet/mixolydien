-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le : Lun 29 Octobre 2012 à 11:00
-- Version du serveur: 5.5.16
-- Version de PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+01:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `mixolydien`
--
CREATE DATABASE mixolydien DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
-- --------------------------------------------------------

-- Creéation de l'utilisateur

CREATE USER 'darriet'@'localhost' IDENTIFIED BY 'Yg#!+=42';
GRANT ALL ON mixolydien.* TO 'darriet'@'localhost' IDENTIFIED BY 'Yg#!+=42';

-- entrer dans la bonne base

use mixolydien
--
-- Structure de la table `musiques`
--

CREATE TABLE IF NOT EXISTS `musiques` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `auteur` varchar(255) NOT NULL,
  `album` varchar(255) NOT NULL,
  `genre` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `musiques`
--

INSERT INTO `musiques` (`id`, `titre`, `auteur`, `album`, `genre`) VALUES
(5, 'A ma fille', 'Aznavour', '', 'variété'),
(6, 'About a revolution', 'Tracy chapman', '', 'pop'),
(7, 'All is white', 'Emilie Simon', 'March of the empress', ''),
(8, 'Camille se maquille', 'Cédric Gervy', 'le Belge', 'variété'),
(9, 'Le jour le plus froid du monde', 'Dionysos', 'La mécanique du coeur', 'pop'),
(10, 'Mon coloc', 'Max boublil', '', 'humour');

-- --------------------------------------------------------

--
-- Structure de la table `playlistes`
--

CREATE TABLE IF NOT EXISTS `playlistes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `id_musique` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `playlistes`
--

INSERT INTO `playlistes` (`id`, `email`, `id_musique`) VALUES
(10, 'e', 5);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE IF NOT EXISTS `utilisateurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `mdp` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Contenu de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `email`, `mdp`, `nom`, `prenom`) VALUES
(5, 'e', 'e', 'e', 'e');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
