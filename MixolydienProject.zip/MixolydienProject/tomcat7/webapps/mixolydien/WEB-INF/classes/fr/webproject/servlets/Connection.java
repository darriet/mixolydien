package fr.webproject.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fr.webproject.methodes.User;

public class Connection extends HttpServlet {
	private static final long serialVersionUID = -9126404742430962518L;

public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
		HttpSession http_session = request.getSession();
		String connect = request.getParameter( "connect" );
		
		if(connect != null){
			request.setAttribute( "connect", connect );
		}
		
		//gestion de la connection
		String session = (String) http_session.getAttribute("session");
		if(session != null){
			if(session.equals("ok")){
				request.setAttribute( "session", session );
			}
		}
		
		request.setAttribute( "url",  http_session.getAttribute("url"));
		request.setAttribute( "noms", http_session.getAttribute("noms") );
		request.setAttribute( "taille",http_session.getAttribute("taille") );
		
		this.getServletContext().getRequestDispatcher( "/WEB-INF/connection.jsp" ).forward( request, response );
	}
	 public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
		String form = request.getParameter("form"); 
		HttpSession http_session = request.getSession();
		if(form !=null){
			if(form.equals("connection")){
				String email = request.getParameter("email");
				String pass = request.getParameter("pass");
				if(email !=null && pass != null){
		        	if(!email.equals("") && !pass.equals("")){
		        		User user = new User();
		        		int confirm = user.connection(email, pass);
		        		if(confirm > -1){
		        			
				        	http_session.setAttribute("session", "ok");
				        	http_session.setAttribute("email", email);
				        	request.setAttribute( "retour", "ok" );
		        		}
		        		else{
			        		String retour = "erreur";
				        	request.setAttribute( "retour", retour );
				        	request.setAttribute( "connect", form );
			        	}
		        	}
		        	else{
		        		String retour = "champs";
			        	request.setAttribute( "retour", retour );
			        	request.setAttribute( "connect", form );
		        	}
		        }
				else{
					String retour = "erreur";
		        	request.setAttribute( "retour", retour );
		        	request.setAttribute( "connect", form );
				}
			}
			if(form.equals("inscription")){
				String email = request.getParameter("email");
				String pass = request.getParameter("pass");
				String nom = request.getParameter("nom");
				String prenom = request.getParameter("prenom");
				if(email !=null && pass != null && nom != null && prenom != null){
		        	if(!email.equals("") && !pass.equals("") && !prenom.equals("") && !nom.equals("")){
		        		User user = new User();
		        		int confirm = user.inscription(email, pass, nom, prenom);
		        		if(confirm > -1 ){
				        	http_session.setAttribute("session", "ok");
				        	http_session.setAttribute("email", email);
				        	request.setAttribute( "retour", "ok" );
		        		}
		        		else{
		        			if(confirm == -2){
		        				String retour = "unicite";
		        				request.setAttribute( "retour", retour );
		        				request.setAttribute( "connect", form );
		        			}
		        			else{
		        				String retour = "erreur";
		        				request.setAttribute( "retour", retour );
		        				request.setAttribute( "connect", form );
		        			}
			        	}
		        	}
		        	else{
		        		String retour = "champs";
			        	request.setAttribute( "retour", retour );
			        	request.setAttribute( "connect", form );
		        	}
		        }
				else{
					String retour = "erreur";
		        	request.setAttribute( "retour", retour );
		        	request.setAttribute( "connect", form );
				}
			}
		}
        this.getServletContext().getRequestDispatcher( "/WEB-INF/connection.jsp" ).forward( request, response );
	 }
}
