package fr.webproject.methodes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class User {
	public int  inscription(String email,  String mdp, String nom, String prenom ){
		int confirm=-1;
		/* Connexion à la base de données */
	    String url = "jdbc:mysql://localhost:3306/mixolydien";
	    String utilisateur = "darriet";
	    String motDePasse = "Yg#!+=42";
	    
	    Connection connexion = null;
	    Statement statement = null;
	    ResultSet resultat = null;
	  //on charge le driver
		 try {
			 Class.forName( "com.mysql.jdbc.Driver" );
		} 
		 catch ( ClassNotFoundException e ) {
		}

	    try{
	    	connexion = DriverManager.getConnection( url, utilisateur, motDePasse );
	    	statement = connexion.createStatement();
	    	//test unicité
	        resultat = statement.executeQuery("SELECT email FROM utilisateurs WHERE email = '"+email+"';");
	        while ( resultat.next() ) {
	             confirm++;
	         }
	        if(confirm==-1){
	    	//inscription 
	        	statement.executeUpdate("INSERT INTO utilisateurs VALUES (0, '"+email+"', '"+mdp+"', '"+nom+"', '"+prenom+"') ");
	        	confirm=1;
	        }
	        else{
	        	confirm = -2;
	        }
	    }
	    catch ( SQLException e ) {
	    }
	    finally {
	        if ( statement != null ) {
	            try {
	                statement.close();
	            } catch ( SQLException ignore ) {
	            }
	        }
	        if ( connexion != null ) {
	            try {
	                connexion.close();
	            } catch ( SQLException ignore ) {
	            }
	        }
	    }
	    return confirm;
	}
	
	public int connection(String email, String mdp){
		int result = -1;
		/* Connexion à la base de données */
	    String url = "jdbc:mysql://localhost:3306/mixolydien";
	    String utilisateur = "darriet";
	    String motDePasse = "Yg#!+=42";
	    
	    Connection connexion = null;
	    Statement statement = null;
	    ResultSet resultat = null;
	  //on charge le driver
		 try {
			 Class.forName( "com.mysql.jdbc.Driver" );
		} 
		 catch ( ClassNotFoundException e ) {
		}

	    try{
	    	 connexion = DriverManager.getConnection( url, utilisateur, motDePasse );
	    	 statement = connexion.createStatement();
	    	 /* on regarde si ce couple existe */
	         resultat = statement.executeQuery(
	        		"SELECT id, email, mdp FROM utilisateurs WHERE email = '"+email+"' " +
	         		"AND mdp = '"+mdp+"';");
	         
	         while ( resultat.next() ) {
	              result= resultat.getInt("id");
	         }
	    }
	    catch ( SQLException e ) {
	    }
	    finally {
	      
	        if ( resultat != null ) {
	            try {
	                resultat.close();
	            } catch ( SQLException ignore ) {
	            }
	        }
	        if ( statement != null ) {
	            try {
	                statement.close();
	            } catch ( SQLException ignore ) {
	            }
	        }
	        if ( connexion != null ) {
	            try {
	                connexion.close();
	            } catch ( SQLException ignore ) {
	            }
	        }
	    }
	    return result;
	}
}
