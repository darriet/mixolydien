package fr.webproject.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Accueil extends HttpServlet {
	private static final long serialVersionUID = -802506238315746724L;
	
	public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
		String connect = request.getParameter("connect");
		HttpSession http_session = request.getSession();
		//déconnection
		if(connect !=null){
			if(connect.equals("out")){
				http_session.setAttribute("session", "out");
			}
		}
		
		//gestion de la connection
		String session = (String) http_session.getAttribute("session");
		if(session != null){
			if(session.equals("ok")){
				request.setAttribute( "session", session );
			}
		}
		
		//on organise la playliste par defaut
		if(http_session.getAttribute("url")==null){
			request.setAttribute( "url", "6#7#8" );
			request.setAttribute( "noms", "Talkin Bout a revolution#All is White#Camille se Maquille#");
			request.setAttribute( "taille", "3" );
			
			http_session.setAttribute("url", "6#7#8");
			http_session.setAttribute("noms", "Talkin Bout a revolution#All is White#Camille se Maquille#");
			http_session.setAttribute("taille", "3");
		}
		else{
			request.setAttribute( "url",  http_session.getAttribute("url"));
			request.setAttribute( "noms", http_session.getAttribute("noms") );
			request.setAttribute( "taille",http_session.getAttribute("taille") );
		}
		
		this.getServletContext().getRequestDispatcher( "/WEB-INF/accueil.jsp" ).forward( request, response );
	}
	 public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
	        /* Traitement des données du formulaire */
		 this.getServletContext().getRequestDispatcher( "/WEB-INF/accueil.jsp" ).forward( request, response );
	 }

}
