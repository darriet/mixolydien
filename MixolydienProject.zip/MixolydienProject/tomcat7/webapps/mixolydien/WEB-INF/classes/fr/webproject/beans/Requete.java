package fr.webproject.beans;

import java.util.List;

public class Requete {

	private List<String> musiques ;
	private List<String> auteurs ;
	private List<String> albums ;
	private List<String> genres ;
	private List<String> id ;
	private int taille;
	
	public List<String> getId() {
		return id;
	}
	public void setId(List<String> id) {
		this.id = id;
	}
	public int getTaille() {
		return taille;
	}
	public void setTaille(int taille) {
		this.taille = taille;
	}
	public List<String> getMusiques() {
		return musiques;
	}
	public void setMusiques(List<String> musiques) {
		this.musiques = musiques;
	}
	public List<String> getAuteurs() {
		return auteurs;
	}
	public void setAuteurs(List<String> auteurs) {
		this.auteurs = auteurs;
	}
	public List<String> getAlbums() {
		return albums;
	}
	public void setAlbums(List<String> albums) {
		this.albums = albums;
	}
	public List<String> getGenres() {
		return genres;
	}
	public void setGenres(List<String> genres) {
		this.genres = genres;
	}
	
	
}
