package fr.webproject.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fr.webproject.beans.Requete;
import fr.webproject.methodes.Controle;


public class Recherche extends HttpServlet {

	private static final long serialVersionUID = 5277689448289497195L;
	
	public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
		HttpSession http_session = request.getSession();
		
		//gestion de la connection
		String session = (String) http_session.getAttribute("session");
		if(session != null){
			if(session.equals("ok")){
				request.setAttribute( "session", session );
			}
		}
		
		request.setAttribute( "url",  http_session.getAttribute("url"));
		request.setAttribute( "noms", http_session.getAttribute("noms") );
		request.setAttribute( "taille",http_session.getAttribute("taille") );
		
		this.getServletContext().getRequestDispatcher( "/WEB-INF/recherche.jsp" ).forward( request, response );
	}
	 public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
		 Controle controle = new  Controle();
		 String message =  request.getParameter("recherche");
		 HttpSession http_session = request.getSession();
		 //évite d'afficher trop de réponses
		 if(message.length()>1){
			 Requete bean = controle.requete(message);
			 String url="";
			 String noms="";
			 int  taille = bean.getTaille();
			 if(taille>0){
				 for(int i=0; i<taille;i++){
					 url+=bean.getId().get(i)+"#";
					 noms+=bean.getMusiques().get(i)+"#";
				 }
				 http_session.setAttribute("url", url);
				 http_session.setAttribute("noms", noms);
				 http_session.setAttribute("taille", taille);
			 }
			 request.setAttribute( "requete", bean );
		 }
		 
		 this.getServletContext().getRequestDispatcher( "/WEB-INF/recherche.jsp" ).forward( request, response );
	 }
}
