package fr.webproject.methodes;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import fr.webproject.beans.Requete;

public class Controle {
	public Requete requete(String message){
		Requete bean = new Requete();
		List<String> id = new ArrayList<String>() ;
		List<String> musiques = new ArrayList<String>() ;
		List<String> auteurs = new ArrayList<String>() ;
		List<String> albums = new ArrayList<String>() ;
		List<String> genres = new ArrayList<String>() ;
		/* Connexion à la base de données */
	    String url = "jdbc:mysql://localhost:3306/mixolydien";
	    String utilisateur = "darriet";
	    String motDePasse = "Yg#!+=42";
	    
	    Connection connexion = null;
	    Statement statement = null;
	    ResultSet resultat = null;
	  //on charge le driver
		 try {
			 Class.forName( "com.mysql.jdbc.Driver" );
		} 
		 catch ( ClassNotFoundException e ) {
		}

	    try{
	    	
	    	 connexion = DriverManager.getConnection( url, utilisateur, motDePasse );
	    	 statement = connexion.createStatement();
	    	 /* Exécution d'une requête sur musiques*/
	         resultat = statement.executeQuery(
	        		"SELECT id, titre, auteur, album, genre FROM musiques WHERE titre like '%"+message+"%' " +
	         		"OR auteur like '%"+message+"%'" +
	         		"OR album like '%"+message+"%';" 
	        );
	         int taille=0;
	         while ( resultat.next() ) {
	        	 id.add(resultat.getString( "id" ));
	             musiques.add(resultat.getString( "titre" ));
	             auteurs.add(resultat.getString( "auteur" ));
	             albums.add(resultat.getString( "album" ));
	             genres.add(resultat.getString( "genre" ));
	             taille++;
	         }
	         bean.setId(id);
	         bean.setMusiques(musiques);
	         bean.setAuteurs(auteurs);
	         bean.setAlbums(albums);
	         bean.setGenres(genres);
	         bean.setTaille(taille);
	    }
	    catch ( SQLException e ) {
	    	
	    }
	    finally {
	      
	        if ( resultat != null ) {
	            try {
	                resultat.close();
	            } catch ( SQLException ignore ) {
	            }
	        }
	        if ( statement != null ) {
	            try {
	                statement.close();
	            } catch ( SQLException ignore ) {
	            }
	        }
	        if ( connexion != null ) {
	            try {
	                connexion.close();
	            } catch ( SQLException ignore ) {
	            }
	        }
	    }

		return bean;
	}
}
