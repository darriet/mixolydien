package fr.webproject.methodes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import fr.webproject.beans.Requete;

public class Playliste {
	public Requete affiche(String email){
		Requete bean = new Requete();
		List<String> id = new ArrayList<String>() ;
		List<String> musiques = new ArrayList<String>() ;
		List<String> auteurs = new ArrayList<String>() ;
		List<String> albums = new ArrayList<String>() ;
		List<String> genres = new ArrayList<String>() ;
		/* Connexion à la base de données */
	    String url = "jdbc:mysql://localhost:3306/mixolydien";
	    String utilisateur = "darriet";
	    String motDePasse = "Yg#!+=42";
	    
	    Connection connexion = null;
	    Statement statement = null;
	    Statement statement2 = null;
	    ResultSet resultat = null;
	    ResultSet resultat2 = null;
	    
	  //on charge le driver
		 try {
			 Class.forName( "com.mysql.jdbc.Driver" );
		} 
		 catch ( ClassNotFoundException e ) {
		}

	    try{
	    	
	    	 connexion = DriverManager.getConnection( url, utilisateur, motDePasse );
	    	 statement = connexion.createStatement();
	    	 statement2 = connexion.createStatement();
	    	 /* Exécution d'une requête sur Playliste*/
	         resultat = statement.executeQuery("SELECT id_musique FROM playlistes WHERE email = '"+email+"' ;");
	         int taille=0;
	         int id_musique;
	         while ( resultat.next() ) {
	        	 id_musique = resultat.getInt( "id_musique" );
	        	 resultat2=statement2.executeQuery("SELECT * FROM musiques WHERE id ='"+id_musique+"' ;");
	        	 while(resultat2.next()){
	        		 id.add(resultat2.getString( "id" ));
	        		 musiques.add(resultat2.getString( "titre" ));
		             auteurs.add(resultat2.getString( "auteur" ));
		             albums.add(resultat2.getString( "album" ));
		             genres.add(resultat2.getString( "genre" ));
		             taille++;
	        	 }
	            
	         }
	         bean.setId(id);
	         bean.setMusiques(musiques);
	         bean.setAuteurs(auteurs);
	         bean.setAlbums(albums);
	         bean.setGenres(genres);
	         bean.setTaille(taille);
	    }
	    catch ( SQLException e ) {
	    	System.out.println(e.getMessage());
	    }
	    finally {
	      
	        if ( resultat != null ) {
	            try {
	                resultat.close();
	                
	            } catch ( SQLException ignore ) {
	            }
	        }
	        if ( resultat2 != null ) {
	            try {
	                resultat2.close();
	                
	            } catch ( SQLException ignore ) {
	            }
	        }
	        if ( statement != null ) {
	            try {
	                statement.close();
	            } catch ( SQLException ignore ) {
	            }
	        }
	        if ( statement2 != null ) {
	            try {
	                statement2.close();
	            } catch ( SQLException ignore ) {
	            }
	        }
	        if ( connexion != null ) {
	            try {
	                connexion.close();
	            } catch ( SQLException ignore ) {
	            }
	        }
	    }
	    return bean;
	}
	public void ajoute(String email, int id_musique){
		/* Connexion à la base de données */
	    String url = "jdbc:mysql://localhost:3306/mixolydien";
	    String utilisateur = "darriet";
	    String motDePasse = "Yg#!+=42";
	    
	    Connection connexion = null;
	    Statement statement = null;
	    
	    //on charge le driver
		 try {
			 Class.forName( "com.mysql.jdbc.Driver" );
		} 
		 catch ( ClassNotFoundException e ) {
		}

	    try{
	    	connexion = DriverManager.getConnection( url, utilisateur, motDePasse );
	    	statement = connexion.createStatement();
	    	//insertion
	    	statement.executeUpdate("INSERT INTO playlistes VALUES (0, '"+email+"', '"+id_musique+"') ");
	    }catch(SQLException e  ){
	    	
	    }
	    finally {
	    	if ( statement != null ) {
	            try {
	                statement.close();
	            } catch ( SQLException ignore ) {
	            }
	        }
	        if ( connexion != null ) {
	            try {
	                connexion.close();
	            } catch ( SQLException ignore ) {
	            }
	        }
	    }
	}
	public void suppression(String email, int id_musique){
		/* Connexion à la base de données */
	    String url = "jdbc:mysql://localhost:3306/mixolydien";
	    String utilisateur = "darriet";
	    String motDePasse = "Yg#!+=42";
	    
	    Connection connexion = null;
	    Statement statement = null;
	    
	    //on charge le driver
		 try {
			 Class.forName( "com.mysql.jdbc.Driver" );
		} 
		 catch ( ClassNotFoundException e ) {
		}

	    try{
	    	connexion = DriverManager.getConnection( url, utilisateur, motDePasse );
	    	statement = connexion.createStatement();
	    	//insertion
	    	statement.executeUpdate("DELETE FROM playlistes WHERE id_musique='"+id_musique+"' AND email='"+email+"';");
	    }catch(SQLException e  ){
	    	System.out.println(e.getMessage());
	    }
	    finally {
	    	if ( statement != null ) {
	            try {
	                statement.close();
	            } catch ( SQLException ignore ) {
	            }
	        }
	        if ( connexion != null ) {
	            try {
	                connexion.close();
	            } catch ( SQLException ignore ) {
	            }
	        }
	    }
	}
}
